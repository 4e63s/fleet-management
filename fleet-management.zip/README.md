# Fleet Management System / نظام إدارة وتتبع الأسطول

Node.js (TypeScript) + Express + Socket.IO + PostgreSQL/Prisma, and React + Tailwind + Leaflet.

## Quick start / التشغيل السريع

```bash
# 1) Database + API + UI with Docker
docker compose up --build
# (first run) seed the admin user and demo vehicles
docker compose exec backend npx tsx prisma/seed.ts   # or run `npm run seed` locally

# 2) Or locally
cd backend && cp .env.example .env && npm install
npx prisma migrate dev --name init && npm run seed && npm run dev
cd ../frontend && cp .env.example .env && npm install && npm run dev

# 3) Fake devices streaming GPS + health
cd backend && npm run simulate
```

Open http://localhost:5173 and sign in with `admin@fleet.local` / `Admin#12345` (change it immediately).

## Tests / الاختبارات

```bash
cd backend  && npm test            # unit + integration (no database needed, Prisma is mocked)
cd frontend && npm test
```

## Architecture / المعمارية

Modular monolith: every module (`auth`, `vehicles`, `drivers`, `maintenance`, `telemetry`, `alerts`, `dashboard`) receives its dependencies (Prisma, realtime bus) through factory functions. The WebSocket layer is hidden behind a `RealtimeBus` interface, so `telemetry` can be moved to its own service later (publish to Redis/NATS instead of Socket.IO) without touching the other modules. To run several API instances, add the Socket.IO Redis adapter.

الكود مقسّم إلى وحدات مستقلة تستقبل اعتمادياتها عبر دوال إنشاء (factories)، وطبقة WebSocket معزولة خلف واجهة `RealtimeBus`، فيمكن فصل خدمة التتبع لاحقًا إلى خدمة مستقلة دون تعديل بقية الوحدات.

## API summary

| Method | Path | Access |
|---|---|---|
| POST | /api/auth/login, /refresh, /logout | public |
| GET | /api/auth/me | any user |
| POST | /api/auth/users | ADMIN |
| GET/POST/PATCH/DELETE | /api/vehicles, /api/drivers, /api/maintenance | read: any; write: ADMIN/MANAGER; delete: ADMIN |
| POST | /api/maintenance/:id/complete | ADMIN/MANAGER |
| GET | /api/alerts, PATCH /api/alerts/:id/acknowledge | read: any; ack: ADMIN/MANAGER |
| GET | /api/dashboard/summary | any user |
| POST | /api/telemetry/position, /health | device key (`x-device-key`) |
| GET | /api/telemetry/live, /health/overview, /vehicles/:id/positions, /vehicles/:id/health[/latest] | any user |

WebSocket (Socket.IO, `auth: { token }`): `position:update`, `health:update`, `alert:new`.

## Known limits / ملاحظات

- Tokens are kept in `localStorage` in the SPA; for stricter XSS protection move the refresh token to an httpOnly cookie.
- Position/health tables grow quickly; add partitioning or a retention job (and TimescaleDB if volume is high).
- Tests mock Prisma. Add a Postgres-backed test suite (e.g. Testcontainers) before relying on query behaviour such as `mode: "insensitive"`.
